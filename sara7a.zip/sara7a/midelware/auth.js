import jwt from 'jsonwebtoken'; 
import { userModel } from '../DB/models/user.model.js';
 export const auth= ()=>{  
    try { 
        return  async(req,res,next)=>{
            const {authorization} = req.headers  
            console.log({authorization}) 
            if(!authorization.startsWith(process.env.berarKey)){
                res.json({massage:" invalid account "})
            }else{
                const token =authorization.split(process.env.berarKey)[1] 
                console.log({token}) 
                const decoded=jwt.verify(process.env.tokenSign) 
                console.log({decoded})
                if(!decoded||!decoded.id ||!decoded.islogin){
                    res.json({massage:"this token invalid "})
                } else{
                    const user = await userModel.findById(decoded.id).select(` email userName`) 
                    if(!user){
                        res.json({massage:"not rejester user"})
                    } else {
                        req.user=user 
                        next()
                    }
                  
                }
            }
            
         } 
        
    } catch (error) { 
        res.json({massage:"catch error ",error})
        
    }

    }

 
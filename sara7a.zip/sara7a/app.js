  import dotenv from 'dotenv' 
  dotenv.config()
  import * as indexRouter from './index.router.js'  
  import connectDB from './DB/conection.js'
 import express from 'express' 
const app= express()    
const port = 3000 
app.use(express.json()) 
const BasURL= process.env.BasURL
app.use(`${BasURL}/auth`,indexRouter.authRouter) 
app.use(`${BasURL}/user`,indexRouter.userRouter)  
app.use(`${BasURL}/massage`,indexRouter.massageRouter) 


/*app.use("*",(req,res)=>{
    res.json("invalid  URL  404  error ")
}) */  

connectDB ()

app.listen(port,()=>{
    console.log(`server is runing .............,${port}`)
})


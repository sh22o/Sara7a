import {massageModel} from "../../../DB/models/massage.model.js"
 import { userModel } from "../../../DB/models/user.model.js" 


 
 export const SendMassaege= async(req,res)=>{ 
    try { 
    const {userID}=req.params 
    const {text}= req.body 
    const user = await userModel.findById(userID).select('userName') 
    console.log(user)
    if(!user){
        res.json({massage:"not user have with id "})
    }else{
        const newmassage= await massageModel({ receverId:userID,text}) 
        const saveMassage= await newmassage.save()  
        res.json({massage:" done ",saveMassage})
        
    }
        
    } catch (error) { 
        res.json({massage:" catch error ",error})
        
    }
    
 } 
 export const mymassages= async (req,res)=>{
    const listmassage= await massageModel.find({receverId:req.user._id}) 
    res.json({massage:"all masaages ",listmassage})

 } 
 export const deleteMassage = async (req,res)=>{
    try { 
        const {userID} =  req.params 
        const  massage = await massageModel.deleteOne({receverId:req.user._id, _id:id})
        if(massage.deletedCount) { 
            res.json({massage:"Done "})
    }else{
        res.json({massage:"not auth or invalid massage id"})
    }
       
        
    } catch (error) { 
        res.json({massage:"catch error ",error})
        
    }
   
    
 }
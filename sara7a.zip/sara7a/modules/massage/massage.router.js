import {Router} from 'express'  
import {auth} from '../../midelware/auth.js'
import * as massagecontroler from './controler/massage.js'

const router = Router()  
router.post( "/:userID",massagecontroler.SendMassaege)
router.get("/allmassages",auth(),massagecontroler.mymassages)
router.delete("/:userId",auth(),massagecontroler.deleteMassage)








export default router  
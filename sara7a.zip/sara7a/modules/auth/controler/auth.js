import { userModel } from "../../../DB/models/user.model.js"
import bcrypt from 'bcrypt' 
import { nanoid } from 'nanoid'
import jwt from 'jsonwebtoken'; 
import { myEmail } from "../../../services/sendEmail.js" 

 //signup function 
  export const SignUP= async(req,res)=>{ 
    try { 
         //1- take data 
    const {userName,email,password}=req.body 
    //2-check if we have user with this eamil  //find one return {} or null
    const user = await userModel.findOne({email})   
    //3-if user true email arealy in db 
    if(user){
        res.json({massage:"Email Exist "})
    } else{  
        //else make hash and newuser schema 
        const hashpass= await bcrypt.hash(password,8) ; 
        const newUser= new userModel({userName,email,password:hashpass}) 
        const savedUser= await newUser.save()   
        const token= jwt.sign({id:savedUser._id},process.env.emailTokenSign,{expiresIn:'5h'})
        const Rerftoken= jwt.sign({id:savedUser._id},process.env.emailTokenSign,{expiresIn:'2*60'})
        const link = `${req.protocol}://${req.headers.host}${process.env.BasURL}/auth/cofEmail/${token}`
        const linkref = `${req.protocol}://${req.headers.host}${process.env.BasURL}/auth/REftoken/${token}`
         const massage =
          ` <a href='${link}'> follow the link to activate </a>
          <br>
          <br> 
           <a href='${linkref}'> request new confirmation email </a>`
        myEmail(savedUser.email,massage)
        res.json({massage:"Done",savedUser,link})


    }
        
    } catch (error) { 
        res.json({massage:"catch error",error})
        
    }
   
 }  
 

 //cofEmail function 
 export const  cofEmail  = async (req,res)=>{ 
    try { 
        const {token} =req.params  
        const decoded=jwt.verify(token,process.env.emailTokenSign) 
        const user =await userModel.updateOne({_id:decoded.id,cofEmail:false},{cofEmail:true},{new:true})  
        console.log(user) 
        //why we put modifiedCount
        user.modifiedCount? res.json({massage:"done please login" }) :  
        res.json({massage:"invalid account " })
        
    } catch (error) { 
        res.json({massage:" catch error" ,error}) 
        console.log(error)
        
    }
   

 } 
 export const REftoken = async (req,res)=>{
    try {
        const token = req.params.token 
        const decoded= jwt.verify(token,process.env.emailTokenSign)
        if(!decoded||!decoded.id){
            res.json("invalid token ")
        }else{
            const user = await userModel.findById(decoded.id).select(`userName email cofEmail `)
            if(!user){
                res.json({massage:"not rejester user "})
            } else { 
                if(user.cofEmail){
                    res.json({massage:"aready confirmed "})
                }else{
                    const token = jwt.sign({id:id._id},process.env.emailTokenSign,{expiresIn:2*60}) 
                    const link = `${req.protocol}://${req.headers.host}${process.env.BasURL}/auth/cofEmail/${token}`
                    const massage =
                    ` <a href='${link}'> follow the link to activate </a>`
    
                    myEmail(savedUser.email,massage)
                    res.json({massage:"Done",link})
    
    
                }
    
            }
        }
    
        
    } catch (error) { 
        res.json("catch error ",error)
        
    }
  

 }
 export const Code =  async(req,res)=>{ 
    try { 
        const {email} = req.body  
        //ليه هنا عملنا select للايميل و اليوزر معنى بس محتاجه check اذا كان الايميل موجود ولا لاء 
        const user = await  userModel.findOne({email}) 
        if(!user){
            res.json({massage:" invalid email "})
        }else{ 
           
            const acssesCode = nanoid()
            // Math.floor(Math.random()*(2022 - 1990) + 5894) 
            await userModel.findOneAndUpdate((user._id),{code:acssesCode}) 
            myEmail(user.email,`<h1>access code :${acssesCode}</h1>`) 
            res.json({massage:"done check your email "})
        }
        
    } catch (error) { 
        res.json({massage:"catch error ",error})
        
    }
   
 }  

 //forgetPass not work have error  => all the time invalid email and password 
  export const forgetPass= async (req,res)=>{  
    const {email,password,code}=req.body   

    if(!code){ 
        res.json("Account  not require forget pass yet ")

    }else{ 
        try {
            const user =  await  userModel.findOne({email,code})   
          console.log({user})//user null ?? 
            if(!user){ 
                res.json({massage:" invalid account  or invalid code "})
            } else{ 
                const hashpass= bcrypt.hash(password,8) 
                await userModel.findOneAndUpdate({id:user._id},{password:hashpass},{code:''}) 
                res.json({massage:"Done"})
        
            }
        
        } catch (error) { 
            res.json({massage:"catch error",error})
            
        }
    }
    
   


  }   


  



















/*export const code= async(req,res)=>{ 
    try {
        const {email} =req.body 
        const user = await userModel.findOne({email}).select(`email userName`) 
        if(!user){
            res.json({massage:"not rejester account "})
        } else{
            const code= Math.floor(Math.random()*(2022 - 1990) + 5894)
            await userModel.findOneAndUpdate((user._id),{code:code})
            myEmail(user.email,`<h>acsses code :${code }</h>`)
            res.json({massage:"done "})
        }
    
        
    } catch (error) { 
        res.json({massage:"catch error ",error})
        console.log(error)
        
    }
  
 }  
//forget password 
export const forgetpass=async(req,res)=>{
    try{
        const {code,email,password} =req.body
        const user= await userModel.findOne({email,code})
        if(!user){
            res.json({massage:"invalid account "})
        }else{
            const hashpass= await bcrypt.hash(password,8)
            await userModel.findOneAndUpdate({id:user._id},{password:hashpass} ,{code:''}) 
            res.json({massage:"done"})
        }
    } catch (error) {
        res.json({massage:"catch error ",error})
    }
}
*/




















 //signin function 
 export const SignIn= async(req,res)=>{ 
    try { 
    const {email,password}=req.body 
    const user = await userModel.findOne({email})   
    
    if(!user){ 
        res.json({massage:"Email not Exist "}) 
       
    } else{   
        if(!user.cofEmail){ 
            res.json({massage:"please , confirm your email first "})
            
        }else{ 
            const match= await bcrypt.compare(password,user.password) ;  
        if(!match){
            res.json({massage:"in-valid password "})
        }else{ 
            const token = jwt.sign({id:user._id , islogin:true },process.env.tokenSign)
            res.json({massage:"Done",token}) 
        }

        }
        
    }  
    } catch (error) { 
        res.json({massage:"catch error",error})
        
    }
   
 } 

import {Router} from 'express' 
import * as authcontroller from './controler/auth.js'
const router = Router()  
router.post( "/SignUP",authcontroller.SignUP) 
router.get( "/cofEmail/:token",authcontroller.cofEmail)
router.get( "/REftoken/:token",authcontroller.cofEmail) 
router.patch("/code",authcontroller.Code) 
router.patch("/forgetPass",authcontroller.forgetPass)
router.post( "/SignIn",authcontroller.SignIn) 



   







export default router  
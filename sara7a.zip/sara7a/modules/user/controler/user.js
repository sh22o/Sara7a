import { userModel } from "../../../DB/models/user.model.js"
import bcrypt from 'bcrypt'

 
 export  const allusers= async (req,res)=>{ 
    try { 
        const user= await userModel.find({}) 
        res.json({massage:"done ", user})
        
    } catch (error) { 
        res.json({massage:"catch error ",error})
        
    }

 } 
 export const profile =async (req,res)=>{
    try { 
    const user = await userModel.findById(req.user._id) 
    console.log(user)
     res.json({massage:"user profile ",user})
        
    } catch (error) { 
        res.json({massage:"catch error",error})
        
    }
 } 
 export const GetshareProfile = async (req,res )=>{
    try { 
        const user = await userModel.findById(req.params.id).select(`userName`)
         res.json({massage:"user profile ",user})
            
        } catch (error) { 
            res.json({massage:"catch error",error})
            
        }

 } 
 export  const GetAllUser = async (req,res,next)=>{
    try {
      const UserList= await userModel.find({})
        res.json({massage:" Done ",UserList})
        console.log(UserList)
        
    } catch (error) {
        console.log(error)
        res.json({massage:"catch error ",error})
        
    }
  

} 
// find user by id 
export  const userById = async (req,res,next)=>{
    try {
       const user = await userModel.findById(req.params.id) 

        res.json({massage:" Done ",user})
        
    } catch (error) {
        res.json({massage:"catch error ",error})
        
    }
  

} 
//update user 

export const UpdateUser= async (req,res,next)=>{
        const {id}=req.params
        const {phone,age} =req.body
        const user = await userModel.findByIdAndUpdate({ _id:id} ,

            {
                phone , age 
            },{
                // without new the console not return update of user 
                new :true
            })

            res.json({massage:"done ",user})
    } 

//delete user  
//all requests of delete not wotk 
export const deleteUser = async (req,res)=>{  
    try { 
        const {id} = req.params 
        
        const user = await userModel.findByIdAndDelete(id) 
     
     // need to return allusers in this step
         res.json({massage:"done",user})
        
    } catch (error) { 
        res.json({massage:" catch error" , error})
        
    }
      
        
    
   


}   
export const updatePass = async  (req,res)=>{
    try {
        const {oldpassword,newpassword} =req.body 
        const user = await userModel.findById(req.user._id) 
        const match = bcrypt.compare(oldpassword,user.password) 
        if(!match){
            res.json({massage:"invalid password "})
        }else{
            const hashpass = await bcrypt.hash(newpassword,8)
            await userModel.findOneAndUpdate({_id:user.id},{password:hashpass})
            res.json({massage:"Done"})
        }
    } catch (error) { 
        res.json({massage:"catch error ",error})
        console.log(error)
        
    }
   
}

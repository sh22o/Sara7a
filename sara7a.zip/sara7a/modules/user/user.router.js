import {Router} from 'express' 
import * as userControler from './controler/user.js'  
import {auth} from '../../midelware/auth.js'
const router = Router()   

//router.get( "/",userControler.allusers) 
router.get("/",auth(),userControler.profile)
router.get("/:id",userControler.GetshareProfile)
router.get("/allusers",userControler.allusers)
router.get("/:id" ,userControler.userById)
router.patch("/:id",userControler.UpdateUser)
router.delete("/:id",userControler.deleteUser)
router.patch("/password",auth(),userControler.updatePass)








export default router  
import mongoose from "mongoose"; 


const userSchema = new mongoose.Schema({
  fname:String,
  lname:String,
  userName:{
    type:String,
    required :true 
  },
  email:{
    type:String,
    required:true, 
   unique :true 
  },
  cofEmail:{
    type:Boolean,
    default:false
  },
  password:{
    type:String,
    required:true
  },
  phone:String,
  age:Number, 
  gender:{
    type:String, 
    default:'female',
     enum:['male','female'],
    required:true 

  },
  profilePIC:String,
  coverPIC:Array, 
  online:{
   type: Boolean,
   default:false
  },
  lastSeen:{
    type:Date
  },
  code:{
    type:String
  }


  


},{
    timestamps:true
}) 

export const userModel =mongoose.model('User',userSchema)
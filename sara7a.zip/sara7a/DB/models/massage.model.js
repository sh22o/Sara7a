import mongoose from "mongoose"; 


const massageSchema = new mongoose.Schema({
  
    text:{
        type:String,
        required:true
    },
    receverId:{
        type:mongoose.Schema.Types.ObjectId,
        ref:"User" ,
        required:true 
    }

  


},{
    timestamps:true
}) 

export const massageModel =mongoose.model('massage',massageSchema)
 import mongoose  from "mongoose"; 

 const connectDB =  async () =>{
    return await mongoose.connect(`mongodb://localhost:27017/sara7haDB `)
 .then(result=>{
    console.log("connect to DB.... ") 
    //console.log(result) 
    
 }).catch(error=>console.log(`faild to connectDB ${error}`)) 
}
 
 export default connectDB
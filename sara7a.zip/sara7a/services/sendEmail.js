

import nodeoutlook from 'nodejs-nodemailer-outlook'
   export function myEmail(dest,massage){
    
    nodeoutlook.sendEmail({
        auth: {
            user: "rout138@outlook.com",
            pass: "123aou123"
        },
        from: "rout138@outlook.com",
        to: dest,
        subject: 'Hey you, awesome!',
        html: massage,
        onError: (e) => console.log(e),
        onSuccess: (i) => console.log(i)
    }
    
    
    );



 }
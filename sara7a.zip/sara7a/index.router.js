import userRouter from './modules/user/user.router.js '  
import massageRouter from './modules/massage/massage.router.js' 
import authRouter from './modules/auth/auth.router.js' 
export {
    userRouter,
    massageRouter,
    authRouter
}